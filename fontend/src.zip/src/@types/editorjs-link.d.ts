declare module '@editorjs/link' {
  const LinkTool: any;
  export default LinkTool;
}
