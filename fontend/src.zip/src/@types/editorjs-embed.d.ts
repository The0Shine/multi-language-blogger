// src/@types/editorjs-embed.d.ts
declare module '@editorjs/embed' {
  const Embed: any;
  export default Embed;
}
