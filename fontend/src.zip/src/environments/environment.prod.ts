export const environment = {
  production: true,
  apiUrl: 'http://localhost:3000/', // Change this to your production API URL
};
